
  function myfunction() {
    var addElement = document.getElementById("add");
    var numberValue = document.myform.number.value;
  var firstfour = numberValue.slice(0,4)
    if (firstfour === "1234" ) {
      addElement.style.backgroundImage = "url(one.png)";
      addElement.style.backgroundRepeat = "no-repeat";
      addElement.innerHTML = ""; 
    } else if (firstfour === "2345") {
      addElement.style.backgroundImage = "url(two.png)";
      addElement.style.backgroundRepeat = "no-repeat";
      addElement.innerHTML = "";
    } else if (firstfour === "3456") {
      addElement.style.backgroundImage = "url(three.png)";
      addElement.style.backgroundRepeat = "no-repeat";
      addElement.innerHTML = "";
    } else if (firstfour === "4567") {
      addElement.style.backgroundImage = "url(four.png)";
      addElement.style.backgroundRepeat = "no-repeat";
      addElement.innerHTML = "";
    } 
    else {
      addElement.innerHTML = "Invalid card number";
      addElement.style.color = "red";
      
    }
  }

function card(start) {
  if (start.number.value == "") {
    alert("please enter your card number!!");
    start.number.focus();
    return false;
  } else if (start.uname.value == "") {
    alert("please enter your username!!");
    start.uname.focus();
    return false;
  } else if (start.date.value == "") {
    alert("please enter your expiry date!!");
    start.date.focus();
    return false;
  } else if (start.code.value == "") {
    alert("please enter your security code!!");
    start.code.focus();
    return false;
  }
  return true;
}
