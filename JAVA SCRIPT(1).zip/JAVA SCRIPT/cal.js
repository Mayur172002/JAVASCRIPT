//  const keys = document.querySelectorAll(".key")
//  const input = document.getElementById("two")
//  const output = document.getElementById("three")

//  keys .forEach(key => {
//     key.addEventListener("click",() => {
//         const keyValue = key.dataset.key;

//         if(keys === "clear"){
//             input.value=''
//             output.value=''
//         }
//         else if(keyValue === "="){
//        try {
//         output .value = eval(input.value)
//        }
//        catch(error){
//         output.value = "error"
//        }
//     }
//     else{
//         input.value += keyValue;
//     }
//     })
//  });

// const keys = document.querySelectorAll(".key")
// const input = document.getElementById("two")
// keys .forEach(key => {
//    key.addEventListener("click",() => {
//        const keyValue = key.dataset.key;

//        if(keys === 'clear'){
//            input.value=''
//        }
//        else if(keyValue === "="){
//       try {
//        input .value = eval(input.value)
//        input.style="color : green"
//       }
//       catch(error){
//        input.value = "ERROR"
//        input.style="color : red"
//       }
//    }
//    else{
//        input.value += keyValue;
//    }
//    })
// });


// const keys = document.querySelectorAll(".key");
// const input = document.getElementById("two");

// keys .forEach(key => {
//     key .addEventListener("click",() => {
//         const keyValue = key.dataset.key;

//         if (keys === "celar"){
//             input .value=''
//         }
//         else if(keyValue === "="){
//         try{
//             input.value = eval(input.value)
//         }
//         catch(error){
//    input.value="error"
//         }
//         }
//         else{
//             input.value += keyValue;
//         }
//     })
// });

const keys = document.querySelectorAll(".key");
const input = document.getElementById("two");

keys.forEach(key => {
    key.addEventListener("click", () => {
        const keyValue = key.dataset.key;

        if (keyValue === "clear") {
            input.value = '';
        }
         else if (keyValue === "=") {
            try {
                input.value = eval(input.value);
            } catch (error) {
                input.value = "error";
            }
        } else {
            input.value += keyValue;
        }
    });
});
